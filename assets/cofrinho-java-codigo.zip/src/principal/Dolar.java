package principal;

// Classe que representa a moeda Dólar (USD)
public class Dolar extends Moeda {

    // Cotação definida pelo aluno (pode alterar se quiser)
    private static final double COTACAO_DOLAR = 5.70;

    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Dólar - US$ " + getValor());
    }

    @Override
    public double converter() {
        // Converte o valor em dólar para reais
        return getValor() * COTACAO_DOLAR;
    }
}
