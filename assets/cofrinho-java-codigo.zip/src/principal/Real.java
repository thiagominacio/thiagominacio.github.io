package principal;

// Classe que representa a moeda Real (BRL)
public class Real extends Moeda {

    public Real(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Real - R$ " + getValor());
    }

    @Override
    public double converter() {
        // Real já está em reais
        return getValor();
    }
}

