package principal;

// Classe que representa a moeda Euro (EUR)
public class Euro extends Moeda {

    // Cotação definida pelo aluno (pode alterar se quiser)
    private static final double COTACAO_EURO = 6.20;

    public Euro(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Euro - € " + getValor());
    }

    @Override
    public double converter() {
        // Converte o valor em euro para reais
        return getValor() * COTACAO_EURO;
    }
}

