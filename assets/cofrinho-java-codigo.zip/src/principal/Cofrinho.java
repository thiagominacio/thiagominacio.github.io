package principal;

import java.util.ArrayList;

// Classe que representa o cofrinho de moedas
public class Cofrinho {

    // Encapsulamento: lista privada de moedas
    private ArrayList<Moeda> listaMoedas = new ArrayList<>();

    // Adiciona uma moeda ao cofrinho
    public void adicionar(Moeda m) {
        listaMoedas.add(m);
    }

    // Lista todas as moedas do cofrinho
    public void listar() {
        if (listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
            return;
        }

        System.out.println("Moedas no cofrinho:");
        for (Moeda m : listaMoedas) {
            // Polimorfismo: cada tipo de moeda exibe sua info
            m.info();
        }
    }

    // Calcula o total convertido para Real
    public double totalConvertido() {
        double total = 0;
        for (Moeda m : listaMoedas) {
            // Polimorfismo: cada tipo converte do seu jeito
            total += m.converter();
        }
        return total;
    }

    /**
     * Remove uma moeda do cofrinho com base no tipo e no valor informado.
     *
     * @param tipo 1 = Real, 2 = Dólar, 3 = Euro
     * @param valor valor da moeda a remover
     * @return true se removeu alguma moeda, false se não encontrou
     */
    public boolean remover(int tipo, double valor) {

        for (int i = 0; i < listaMoedas.size(); i++) {
            Moeda m = listaMoedas.get(i);

            // Verifica o tipo
            boolean tipoConfere = false;

            if (tipo == 1 && m instanceof Real) {
                tipoConfere = true;
            } else if (tipo == 2 && m instanceof Dolar) {
                tipoConfere = true;
            } else if (tipo == 3 && m instanceof Euro) {
                tipoConfere = true;
            }

            // Se o tipo confere e o valor também, remove
            if (tipoConfere && m.getValor() == valor) {
                listaMoedas.remove(i);
                return true; // removeu uma moeda e sai
            }
        }

        // Nenhuma moeda encontrada com esse tipo e valor
        return false;
    }
}

