package principal;

// Classe abstrata que representa uma moeda genérica
public abstract class Moeda {

    // Encapsulamento: atributo privado
    private double valor;

    // Construtor que recebe o valor da moeda
    public Moeda(double valor) {
        this.valor = valor;
    }

    // Getter para permitir acesso controlado ao valor
    public double getValor() {
        return this.valor;
    }

    // Método abstrato para exibir informações da moeda
    public abstract void info();

    // Método abstrato para converter a moeda para Real (R$)
    public abstract double converter();
}

