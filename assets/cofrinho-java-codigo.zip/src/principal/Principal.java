package principal;

import java.util.Scanner;

// Classe principal com o menu de interação com o usuário
public class Principal {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();

        int opcao = -1;

        do {
            System.out.println("\n=== COFRINHO DE MOEDAS ===");
            System.out.println("1 - Adicionar moeda");
            System.out.println("2 - Remover moeda");
            System.out.println("3 - Listar moedas");
            System.out.println("4 - Somar total convertido para Real");
            System.out.println("0 - Encerrar");
            System.out.print("Escolha uma opção: ");

            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("\nEscolha o tipo de moeda para adicionar:");
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    System.out.print("Tipo: ");
                    int tipoAdicionar = sc.nextInt();

                    System.out.print("Digite o valor da moeda: ");
                    double valorAdicionar = sc.nextDouble();

                    if (tipoAdicionar == 1) {
                        cofrinho.adicionar(new Real(valorAdicionar));
                        System.out.println("Moeda Real adicionada!");
                    } else if (tipoAdicionar == 2) {
                        cofrinho.adicionar(new Dolar(valorAdicionar));
                        System.out.println("Moeda Dólar adicionada!");
                    } else if (tipoAdicionar == 3) {
                        cofrinho.adicionar(new Euro(valorAdicionar));
                        System.out.println("Moeda Euro adicionada!");
                    } else {
                        System.out.println("Tipo de moeda inválido.");
                    }
                    break;

                case 2:
                    System.out.println("\nRemoção de moeda");
                    System.out.println("Escolha o tipo de moeda que deseja remover:");
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    System.out.print("Tipo: ");
                    int tipoRemover = sc.nextInt();

                    System.out.print("Digite o valor da moeda que deseja remover: ");
                    double valorRemover = sc.nextDouble();

                    boolean removida = cofrinho.remover(tipoRemover, valorRemover);

                    if (removida) {
                        System.out.println("Moeda removida com sucesso!");
                    } else {
                        System.out.println("Nenhuma moeda encontrada com esse tipo e valor.");
                    }
                    break;

                case 3:
                    System.out.println();
                    cofrinho.listar();
                    break;

                case 4:
                    double total = cofrinho.totalConvertido();
                    System.out.println("\nTotal no cofrinho convertido para Real: R$ " + total);
                    break;

                case 0:
                    System.out.println("\nEncerrando o programa...");
                    break;

                default:
                    System.out.println("\nOpção inválida. Tente novamente.");
                    break;
            }

        } while (opcao != 0);

        sc.close();
    }
}

