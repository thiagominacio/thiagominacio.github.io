# Cofrinho Multimoedas — Java (projeto acadêmico)

Aplicação de console com as classes Moeda, Real, Dolar, Euro, Cofrinho e Principal.

## Compilar e executar (JDK instalado)

Linux/macOS (a partir da pasta do ZIP extraído):

```bash
mkdir -p out
javac -encoding UTF-8 -d out src/principal/*.java
java -cp out principal.Principal
```

Windows PowerShell (a partir da pasta do ZIP extraído):

```powershell
mkdir out
javac -encoding UTF-8 -d out src/principal/*.java
java -cp out principal.Principal
```

As cotações no código são constantes didáticas, e não taxas de câmbio em tempo real.
